CBN 24 NEWS POST MAKER - FIXED v2

इस प्रोजेक्ट में मुख्य सुधार:
1. फोटो चुनने पर चुनी हुई फोटो पोस्ट में आती है।
2. पोस्ट का आउटपुट 1080 x 1920 है।
3. CBN 24 का लोगो/हेडर शामिल है।
4. Headline, समाचार, फोटो, संवाददाता और स्थान एक ही पोस्ट में आते हैं।
5. पोस्ट Pictures/CBN24 फोल्डर में सेव होती है।
6. Hindi/Devanagari text के लिए Android का sans font इस्तेमाल किया गया है।

बिल्ड:
- Android Studio में इस folder को Open करें।
- Gradle Sync होने दें।
- Build > Build APK(s) चुनें।

नोट: इस ZIP में source project है। इस environment में Android SDK/build tools उपलब्ध न होने के कारण यहां से installable APK compile नहीं की जा सकी।
