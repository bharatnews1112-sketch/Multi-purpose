package com.cbn24.newspostmaker;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.net.Uri;import android.provider.MediaStore;import android.view.*;import android.widget.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
    EditText headline, body, reporter, location; ImageView preview; Bitmap selected; final int PICK=7;
    int blue=Color.rgb(21,101,192);
    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setTextColor(Color.DKGRAY);t.setPadding(4,14,4,6);return t;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(17);e.setPadding(18,12,18,12);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setStroke(1,0xffdddddd);e.setBackground(g);return e;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setTextColor(Color.WHITE);b.setAllCaps(false);GradientDrawable g=new GradientDrawable();g.setColor(blue);g.setCornerRadius(8);b.setBackground(g);return b;}
    void build(){
        ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,12,18,24);root.setBackgroundColor(0xfff4f4f4);scroll.addView(root);
        TextView title=new TextView(this);title.setText("CBN 24 NEWS POST MAKER");title.setTextSize(25);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setTextColor(blue);title.setGravity(Gravity.CENTER);title.setPadding(0,12,0,12);root.addView(title);
        headline=input("मुख्य शीर्षक / Headline"); body=input("समाचार का पूरा विवरण लिखें..."); body.setGravity(Gravity.TOP); body.setMinLines(7); reporter=input("संवाददाता / Reporter"); location=input("स्थान / Location");
        root.addView(label("मुख्य शीर्षक / Headline"));root.addView(headline,new LinearLayout.LayoutParams(-1,65));
        root.addView(label("समाचार का विवरण / News"));root.addView(body,new LinearLayout.LayoutParams(-1,220));
        preview=new ImageView(this);preview.setImageResource(com.cbn24.newspostmaker.R.drawable.cbn24_logo);preview.setScaleType(ImageView.ScaleType.CENTER_CROP);GradientDrawable pg=new GradientDrawable();pg.setColor(0xffdddddd);preview.setBackground(pg);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,330);pp.topMargin=12;root.addView(preview,pp);
        Button photo=btn("📷  फोटो चुनें");root.addView(photo,new LinearLayout.LayoutParams(-1,62)); photo.setOnClickListener(v->pick());
        root.addView(label("संवाददाता / Reporter"));root.addView(reporter,new LinearLayout.LayoutParams(-1,65));root.addView(label("स्थान / Location"));root.addView(location,new LinearLayout.LayoutParams(-1,65));
        TextView size=new TextView(this);size.setText("Story Size: 1080 × 1920");size.setTextSize(18);size.setTypeface(Typeface.DEFAULT,Typeface.BOLD);size.setGravity(Gravity.CENTER);size.setPadding(0,18,0,10);root.addView(size);
        Button make=btn("📰  पोस्ट तैयार करें");root.addView(make,new LinearLayout.LayoutParams(-1,65));make.setOnClickListener(v->generate());
        setContentView(scroll);
    }
    void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&c==RESULT_OK&&d!=null){try{selected=MediaStore.Images.Media.getBitmap(getContentResolver(),d.getData());preview.setImageBitmap(selected);}catch(Exception e){Toast.makeText(this,"फोटो नहीं खुल सकी",Toast.LENGTH_SHORT).show();}}}
    Bitmap fit(Bitmap b,int w,int h){float s=Math.max(w/(float)b.getWidth(),h/(float)b.getHeight());int nw=Math.round(b.getWidth()*s),nh=Math.round(b.getHeight()*s);Bitmap x=Bitmap.createScaledBitmap(b,nw,nh,true);int l=(nw-w)/2,t=(nh-h)/2;return Bitmap.createBitmap(x,l,t,l+w,t+h);}
    ArrayList<String> wrap(String s,Paint p,float max){ArrayList<String> out=new ArrayList<>();for(String para:s.split("\\n")){String line="";for(String word:para.trim().split("\\s+")){String test=line.length()==0?word:line+" "+word;if(p.measureText(test)<=max)line=test;else{if(line.length()>0)out.add(line);line=word;}}if(line.length()>0)out.add(line);}return out;}
    void generate(){String h=headline.getText().toString().trim(),txt=body.getText().toString().trim();if(h.isEmpty()||txt.isEmpty()||selected==null){Toast.makeText(this,"शीर्षक, समाचार और फोटो तीनों भरें",Toast.LENGTH_LONG).show();return;}
        int W=1080,H=1920;Bitmap out=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(out);c.drawColor(Color.WHITE);
        Bitmap logo=BitmapFactory.decodeResource(getResources(),R.drawable.cbn24_logo);c.drawBitmap(fit(logo,1000,205),40,25,new Paint(Paint.ANTI_ALIAS_FLAG));c.drawLine(40,245,1040,245,line(blue,5));
        Paint ph=paint(Color.BLACK,48,true);float y=305;for(String l:wrap(h,ph,1000)){c.drawText(l,40,y,ph);y+=58;}y+=18;
        int ih=500;c.drawBitmap(fit(selected,1000,ih),40,(int)y,new Paint(Paint.ANTI_ALIAS_FLAG));y+=ih+38;
        Paint pb=paint(Color.DKGRAY,31,false);for(String l:wrap(txt,pb,1000)){if(y>1700)break;c.drawText(l,40,y,pb);y+=39;}y+=18;
        Paint meta=paint(Color.BLACK,30,true);String rr=reporter.getText().toString().trim();String loc=location.getText().toString().trim();if(!rr.isEmpty()){c.drawText("संवाददाता: "+rr,40,y,meta);y+=42;}if(!loc.isEmpty())c.drawText("स्थान: "+loc,40,y,meta);
        c.drawLine(40,1820,1040,1820,line(blue,4));Paint foot=paint(0xff555555,24,false);c.drawText("CBN 24 News Post Maker",40,1860,foot);c.drawText("www.citybreakingnews24.online",40,1895,foot);
        try{String name="CBN24_"+System.currentTimeMillis()+".jpg";OutputStream os;if(Build.VERSION.SDK_INT>=29){android.content.ContentValues v=new android.content.ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/CBN24");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);os=getContentResolver().openOutputStream(u);}else{File dir=new File(getExternalFilesDir(null),"CBN24");dir.mkdirs();os=new FileOutputStream(new File(dir,name));}out.compress(Bitmap.CompressFormat.JPEG,95,os);os.close();showShare(out,name);}catch(Exception e){Toast.makeText(this,"पोस्ट सेव नहीं हुई: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    Paint paint(int color,float size,boolean bold){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));return p;}
    Paint line(int color,float w){Paint p=paint(color,w,false);return p;}
    void showShare(Bitmap b,String name){try{File f=new File(getCacheDir(),name);FileOutputStream o=new FileOutputStream(f);b.compress(Bitmap.CompressFormat.JPEG,95,o);o.close();Toast.makeText(this,"पोस्ट Pictures/CBN24 में सेव हो गई",Toast.LENGTH_LONG).show();}catch(Exception e){}}
}
